import time
from selenium import webdriver
from selenium.webdriver.support.ui import Select

Folder = r'C:\Users\YOURNAME\Desktop\LegoCodes'

EMAIL = ''
CODES = []
textdoc = open('LegoCodes.txt','a')
HowMany = 10

def Create_account():
    create = web.find_element_by_class_name('signUpButton')
    create.click()
    over13 = web.find_element_by_id('authorize-age-gate_pc_a_1')
    over13.click()
    nickname = web.find_element_by_id('register-form_pc_input_0')
    nickname.send_keys('gdgf')
    email = web.find_element_by_id('email')
    email.send_keys(GetEmail())
    password = web.find_element_by_id('register-form_pc_input_1')
    confirm = web.find_element_by_id('register-form_pc_input_2')
    password.send_keys("Wertyui2")
    confirm.send_keys("Wertyui2")
    year = Select(web.find_element_by_id('birth-year-field'))
    year.select_by_index(20)
    month = Select(web.find_element_by_id('birth-month-field'))
    month.select_by_index(5)
    day = Select(web.find_element_by_id('birth-day-field'))
    day.select_by_index(20)
    gender = Select(web.find_element_by_xpath('//*[@id="register-form_pc_select_0"]'))
    gender.select_by_index(1)
    region = Select(web.find_element_by_id('region-field'))
    region.select_by_index(1)
    agree = web.find_element_by_class_name('c-checkbox')
    agree.click()
    confirm = web.find_element_by_id('register-form_pc_button_5')
    confirm.click()
    register = web.find_element_by_id('register-email-opt-in-form_pc_button_0')
    register.click()
    verify = web.find_element_by_id("register-pincode-form_pc_input_0")
    verify.send_keys(GetVerify())
    verifybtn = web.find_element_by_id('register-pincode-form_pc_button_0')
    verifybtn.click()
    ok = web.find_element_by_id('register-complete_pc_a_2')
    ok.click()

def Tutorial():
    start = web.find_element_by_xpath('/html/body/div[1]/div[7]/div[1]/div/div/div[3]/div[2]/button')
    start.click()
    earn = web.find_element_by_xpath('/html/body/div[1]/div[2]/div[2]/div/div/div[2]/a/span')
    earn.click()
    collect = web.find_element_by_xpath('/html/body/div/div[2]/div[2]/section[1]/ul/li[1]/div[2]/div[1]/button')
    collect.click()
    time.sleep(2)
    web.get('https://my.nintendo.com/reward_categories')
    reward = web.find_element_by_xpath('/html/body/div/div[2]/div[3]/div[1]/a')
    reward.click()
    item_page = web.find_element_by_class_name('RewardItem_title')
    item_page.click()
    redeem = web.find_element_by_xpath('//*[@id="RewardDetailCanvasScroll"]/div/div[1]/div/div[2]/div[3]/div/button')
    redeem.click()
    confirm = web.find_element_by_xpath('/html/body/div/div[2]/div[3]/div/div/div/div[3]/div[2]/button')
    confirm.click()
    time.sleep(1)

def GetCode():
    web.get('https://my.nintendo.com/rewards/0c46e3d0e19ddbcf?imp=inXF0fgc3NLNWC_HDeM8bco_ONk8FQSIWvej8lP1%3Areward_list%3A1%3A1')
    redeem = web.find_element_by_xpath('//*[@id="RewardDetailCanvasScroll"]/div/div[1]/div/div[2]/div[3]/div/button')
    redeem.click()
    confirm = web.find_element_by_xpath('/html/body/div/div[2]/div[3]/div/div/div/div[3]/div[2]/button')
    confirm.click()
    time.sleep(3)
    code = web.find_element_by_xpath('//*[@id="result"]/div/div[2]/div/div[1]')
    print(code.text)
    textdoc.write(code.text + "\n")

def GetEmail():
    return Emailsite.find_element_by_id('mail_address').get_attribute('value')

def GetVerify():
    time.sleep(25)
    msg = Emailsite.find_element_by_xpath('//*[@id="mail_messages_content"]/div/div[1]/div[3]/span').text
    code = msg[1:5]
    return code


if __name__ == '__main__':
    for i in range(HowMany):
        Emailsite = webdriver.Chrome(Folder + '\chromedriver.exe')
        Emailsite.get('https://10minutemail.com/')
        time.sleep(1)
        web = webdriver.Chrome(Folder + '\chromedriver.exe')
        web.get('https://my.nintendo.com/')
        Create_account()
        Emailsite.close()
        Tutorial()
        GetCode()
        web.close()




